/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package abc_college_assignment;


import java.util.ArrayList;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author Caleb Perumal
 */
public class ABC_College_FunctionsTest {

       
    public ABC_College_FunctionsTest() {

    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Testing has begun");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Testing complete");
    }
    
    @Before
    public void setUp() {
  
    }
    
    @After
    public void tearDown() {
    }


    
    @Test
    public void testSaveStudent() {
        

        ABC_College_Functions result = new ABC_College_Functions();
     
        ArrayList<Integer> expectedIds = new ArrayList<>();
        ArrayList<String> expectedNames = new ArrayList<>();
        ArrayList<Integer> expectedAges = new ArrayList<>();
        ArrayList<String> expectedEmails = new ArrayList<>();
        ArrayList<String> expectedCourses = new ArrayList<>();

        expectedIds.add(123);
        expectedNames.add("Caleb Perumal");
        expectedAges.add(18);
        expectedEmails.add("cal@example.com");
        expectedCourses.add("Computer Science");
 
        

        result.studentId.add(123); 
       result.studentName.add("Caleb Perumal");
        result.studentAge.add(18);
         result.studentEmail.add("cal@example.com"); 
        result.studentCourse.add("Computer Science");

        assertEquals(expectedIds.get(0), result.studentId.get(0));
        assertEquals(expectedNames.get(0), result.studentName.get(0));
        assertEquals(expectedAges.get(0), result.studentAge.get(0));
        assertEquals(expectedEmails.get(0), result.studentEmail.get(0));
      assertEquals(expectedCourses.get(0), result.studentCourse.get(0));
//assertEquals(expectedIds.size(),result.studentId.size());
    }
 

@Test
public void searchStudent(){
// Create yourTestClass instance
       /*
             Test purpose-->
             is to verify if correct user details are outputted *GIVEN THAT THE ID IS CORRECT*
             we accomplish this by simulating the users input from here and then match it to a variable that we know is the same (assert equals)
             then we start to match the student details since we know that a correct id was passed to the method
             if the student detills are correst the test will pass indicating that the id verifier is working
             */
ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

        // Prepare test data
     result.studentId.add(1);
     result.studentId.add(2);
     result.studentId.add(3);

     result.studentName.add("Caleb");
     result.studentName.add("Ishkar");
     result.studentName.add("Nikhile");
     result.studentAge.add(20);
     result.studentAge.add(22);
     result.studentAge.add(25);

     result.studentEmail.add("cal@example.com");
     result.studentEmail.add("ish@example.com");
     result.studentEmail.add("nik@example.com");

    result.studentCourse.add("PROG6122");
    result.studentCourse.add("NWEG5122");
    result.studentCourse.add("PRSE");

// Create a mock Scanner object with user input
Scanner kb = new Scanner("2\n\n"); // Enter student ID 2

 // Call the searchStudent method
String results =result.searchStudent(kb);

   
assertNotNull(results);
    }

// this test check is an invald id is enterd in this method, is it letting the user know that its invalid 
@Test
public void searchStudentNotFound(){
   ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();
   ABC_College_Functions result = new ABC_College_Functions(); 
   
  result.studentId.add(111);
       
 Scanner kb = new Scanner("113\n\n");
 String found = result.searchStudent(kb);
 int IDTest=113;
        

assertEquals("Student with ID: " +IDTest+" was not found!",found);
     }


@Test
public void testDeleteStudent(){

ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

  // Prepare test data
 result.studentId.add(111);
 result.studentId.add(222);
 result.studentId.add(333);

 result.studentName.add("Caleb");
 result.studentName.add("Ishkar");
 result.studentName.add("Nikhilee");
 result.studentAge.add(20);
 result.studentAge.add(22);
 result.studentAge.add(25);

result.studentEmail.add("cal@example.com");
result.studentEmail.add("ish@example.com");
result.studentEmail.add("nik@example.com");

result.studentCourse.add("PROG6122");
result.studentCourse.add("NWEG5122");
result.studentCourse.add("PRSE");
   
 Scanner kb = new Scanner("111\ny\n\n");
 String found = result.deleteStudent(kb);
 String delete="deleted";

  assertEquals(delete,found);
   

}
@Test
public void testDeleteStudentNotFound(){
    
 ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
 ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

 // Prepare test data
     result.studentId.add(111);
     result.studentId.add(222);
     result.studentId.add(333);

    result.studentName.add("Caleb");
    result.studentName.add("Ishkar");
    result.studentName.add("Nikhile");
   result.studentAge.add(20);
   result.studentAge.add(22);
   result.studentAge.add(25);

   result.studentEmail.add("cal@example.com");
   result.studentEmail.add("ish@example.com");
   result.studentEmail.add("nik@example.com");

  result.studentCourse.add("PROG6122");
  result.studentCourse.add("NWEG5122");
  result.studentCourse.add("PRSE");
   
Scanner kb = new Scanner("113\n\n");
 String found = result.deleteStudent(kb);
 String delete="Student with ID: " +113+" was not found!";

assertEquals(delete,found);
   
}
@Test
public void testAgeValidity(){
ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

Scanner kb = new Scanner("20");
int found = result.ageValidity(kb);
int valid =1;

assertEquals(valid,found);


}
@Test
public void testAgeValidity_NotValid(){
ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

Scanner kb = new Scanner("14\n16");
int found = result.ageValidity(kb);
int valid =1;

assertEquals(valid,found);


}
@Test
public void testAgeValidity_NotValidCharacter(){
ABC_College_Functions result = new ABC_College_Functions();  //instantiated this so we can use his for polulating the student details
ABC_College_Functions mo = new ABC_College_Functions(); // nstantiated this for the simulation of the id  being being entered by user 
                                                                                                           //COULD HAVE JUST USED ONE INSTANTANTION -->USED 2 FOR CLARITY (PERSONAL CHOICE)     ABC_College_FunctionsTest mo = new ABC_College_FunctionsTest();

Scanner kb = new Scanner("a\n\n20");
int found = result.ageValidity(kb);
int valid =1;

assertEquals(valid,found);

}
}
    
//ALL TESTS RUNNING 100%
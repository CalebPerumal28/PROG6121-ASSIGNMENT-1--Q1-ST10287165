/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package abc_college_assignment;

import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class ABC_College_Assignment  {
final static Scanner kb = new Scanner (System.in); 
   
    public static void main(String[] args) {
      //this is the main 
      
      
        menuChoice();
    }//end of main
    public static void menuChoice(){
        ABC_College_Functions zo = new ABC_College_Functions();
       
        System.out.println("  STUDENT MANAGEMENT APPLICATION\n"+ 
                                 "***********************************************************");
        zo.firstMenu(kb);
        
    }//method end
    
    public static void  mainMenu(){
        
  ABC_College_Functions mo= new ABC_College_Functions();
//        boolean flag= true;
//        while (flag){
            System.out.println("***********************************************************");
            System.out.println("Please select one of the following menu items :\n"
                +"(1) Capture a new student\n"
                +"(2) Search for a student\n"
                +"(3) Delete a student\n"
                +"(4) Print student report\n"
                +"(5) Exit Application");
              int userInput=kb.nextInt();
              System.out.println("***********************************************************");
        
                         
        
        switch (userInput){
            
            case 1:mo.saveStudent(kb); break;
            case 2:mo.searchStudent(kb); break;
            case 3: mo.deleteStudent(kb); break;
            case 4:mo.displayStudentReport(kb); break;
            case 5:mo.userQuit();  break;// flag= false; 
            default: mainMenu(); break;
        
        }
    }
    
   
        
}//end of class
/*
References:
https://youtu.be/pTAda7qU4LY?si=UCsZgYHmEiKugCkm
https://youtu.be/NbYgm0r7u6o?si=8N_C-Hfw5YsXz3cH
https://youtu.be/fLwIScUeHE4?si=n-iKH-ixHpU2d8AW
https://youtu.be/kGLLtMIamuQ?si=EA7GCe0r-w-yvK5U
https://youtu.be/xk4_1vDrzzo?si=uvYwJfQh-4TeNMvn
https://www.informit.com/articles/article.aspx?p=1021579&seqNum=3'
https://stackoverflow.com/questions/21994005/generic-class-with-generic-arraylist
https://stackoverflow.com/questions/3990093/java-inheritance
Java Programming Joyce Farrell
*/
 

//Q1 DONE
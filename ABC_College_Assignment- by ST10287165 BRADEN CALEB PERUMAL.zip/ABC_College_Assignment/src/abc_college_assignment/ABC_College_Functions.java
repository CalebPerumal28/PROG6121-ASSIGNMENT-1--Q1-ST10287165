/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abc_college_assignment;

import static abc_college_assignment.ABC_College_Assignment.mainMenu;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class ABC_College_Functions {
 final static Scanner kb = new Scanner (System.in); //this scanner can bee used all over the class
    
 static  ArrayList<String> studentName = new ArrayList<>();
 static ArrayList<String > studentCourse = new ArrayList<>(); 
 static ArrayList<String > studentEmail = new ArrayList<>();
 static ArrayList<Integer > studentId = new ArrayList<>();
 static  ArrayList<Integer > studentAge = new ArrayList<>();
 static  ArrayList<Integer> test = new ArrayList<>();
 static  ArrayList<Boolean> check = new ArrayList<>();
    
 // this method saves the students data 
 public static void saveStudent(Scanner kb){
 ABC_College_Assignment mo = new ABC_College_Assignment();   //instantiannting the class to use its methods , array lists, etc
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("**************************************************************************");  
        
       System.out.print("Enter  the student's ID: ");  
       int learnerId= kb.nextInt();
        kb.nextLine();    //comsume new line to that is its empty
        studentId.add(learnerId);
        
        System.out.print("Enter the student's name: "); 
        String name= kb.nextLine();
        studentName.add(name); 
        
        System.out.print("Enter the student's age: ");
        ageValidity(kb); //invoking the ageValidy method
        kb.nextLine();

        boolean flagTwo=true; 
            while (flagTwo){
                System.out.print("Enter student's Email address: "); 
                String learnerEmail=kb.nextLine();
                        if (learnerEmail.contains("@")) {
                              studentEmail.add(learnerEmail);
                              flagTwo=false; //exists loop
                         } else {
                            System.out.println("Email address invalid");
                          }
                                   }
            
        System.out.print("Enter student's course: "); 
        String learnerCourse= kb.nextLine();
        studentCourse.add(learnerCourse);
           
         System.out.println("Students details successfully captured");
         System.out.println("**************************************************************************");       
          firstMenu(kb);  //invoking the mainmenu
        

    }//end of method
        
    //this method is responsible for diaplaying the student report. It displayes all the students along with their details 
 
    public static void displayStudentReport(Scanner kb){
         if ( studentId.size()==0){
              System.out.println("There are no students");
          }
                for (int i = 0; i < studentId.size(); i++){
                    System.out.println("--------------------------------------------------------------------------");
                    System.out.println(
                      "                    Student Report: "+(i+1)+"\n"
                    +"------------------------------------------------------------------------\n"

                    +"Student ID: "+studentId.get(i) +"\n"
                    +"Student Name: " + studentName.get(i)+"\n" 
                    +"Student Age:  "+ studentAge.get(i)+"\n"
                    +"Student Email: "+studentEmail.get(i)+"\n" 
                    +"Student Course: "+studentCourse.get(i)
                                     );
                }
                 System.out.println("------------------------------------------------------------------------------------\n");
              
                 System.out.println("**************************************************************************");   
                 kb.nextLine();
                 firstMenu(kb);
        
   }//end of method
        
    //unnecessary but tryed it...i am aware that i could have used System.exit(0)
 public static void userQuit(){
     System.out.println("You have Quit");
    }
      
 //this method is responsible for search for the student based on their sutdent id
 //once validated it will diaply their details 
 public static String searchStudent(Scanner kb){
            
System.out.print("Please enter the student ID to search: ");
  int StudentIDInput = kb.nextInt();
               
 // int  chek= StudentIDInput ;
System.out.println("------------------------------------------------------------------------------------\n");
String foundItem=null;
   
    for (int i = 0; i < studentId.size(); i++) {
        if (StudentIDInput==studentId.get(i) ) {
      
            foundItem =
                    "Student Report: "+(i+1)+"\n"
            +  "------------------------------------------------------------------------------------\n"
    
             +"Student ID: "+studentId.get(i) +"\n"
             +"Student Name: " + studentName.get(i)+"\n" 
             +"Student Age:  "+ studentAge.get(i)+"\n"
             +"Student Email: "+studentEmail.get(i)+"\n" 
             +"Student Course: "+studentCourse.get(i) ;
           
       }
    }
      if (foundItem != null ) {
    
          System.out.println(foundItem);
           check.add(true);
     
      } else {
      System.out.println("Student with ID: " +StudentIDInput+" was not found!");
      check.add(false);
      foundItem="Student with ID: " +StudentIDInput+" was not found!";
      }
      kb.nextLine();
      System.out.println("------------------------------------------------------------------------------------");
      firstMenu(kb);
     
    
    
return foundItem;
}
 
 //this method containns the menui option fo tthe userrot continue tp exit
 public static void firstMenu(Scanner kb){
    System.out.println("Enter (1) to launch menu or any other key to exit");
    String userChoice= kb.nextLine();
         if (userChoice.equals("1")) {
            mainMenu();
             } else {
                   userQuit();
                  }
        
    }   //end of method
      

// thids method take the student id as an input and then deletes the student of the system
 
public static String deleteStudent(Scanner kb){   //deleting student
  int check=0; 
   int trys=1;
   String returnVal= null;
 
        if(studentId.size()==0) {
           System.out.println("There are no students on the system");
           trys--;
           returnVal=null;
       }

    while (trys!=0){
          System.out.print("Enter the student ID to delete: ");
          int deleteInput= kb.nextInt();
      
            for (int i = 0; i < studentId.size(); i++) {

                    if (deleteInput==studentId.get(i)) {
                        boolean flag = true;
                         String userchoice=null;
                        while (flag){
                        System.out.println("Are you sure you want to delete student "+deleteInput +" from the system:Please enter  \"y/Y\" for yes or \"n/N\" for no");
                  userchoice= kb.next();
                            if (userchoice.equalsIgnoreCase("y")||userchoice.equalsIgnoreCase("n")) {
                                flag=false;
                            }
                        }
                             if (userchoice.equalsIgnoreCase("y")) {
                                    studentName.remove(i);
                                    studentId.remove(i);
                                    studentEmail.remove(i);
                                    studentAge.remove(i);
                                    studentCourse.remove(i);
                    System.out.println("------------------------------------------------------------------------------------\n");
                    System.out.println("Student with ID: "+ deleteInput+" was successfully deleted");
                    System.out.println("------------------------------------------------------------------------------------");
                    returnVal="deleted";
                                  } else {
                                                System.out.println("Delete request canceled");
                                                returnVal=null;
                                                        }
                        check=1;
                             trys--;

                     }
           
     }
     if (check==0 ){
             System.out.println("Student with ID: " +deleteInput+" was not found!");
       returnVal= "Student with ID: " +deleteInput+" was not found!";
       trys--;
     }
         }
   kb.nextLine();
   firstMenu(kb);
   
   return returnVal;
       }//end of method

// this method is responsble for verifying if the age entered wwhrn savbing the student is valid 
public static int ageValidity(Scanner kb){
     boolean myFlag= true;
     int returnVal=0;
        while (myFlag){
                if (kb.hasNextInt()){
                  int learnerAge=kb.nextInt();
                         if(learnerAge>=16){
                             studentAge.add(learnerAge);
                             returnVal=1;
                             myFlag=false;   //exit loop
                                          } else{
                             System.out.println("You have entered a incorrect age!!!");
                             System.out.print("Please re-nter student's age>> ");
                             returnVal=0;
                                                                       }

                                    }
                            else{
                            String wrongDataTypeInput=kb.next();
                              System.out.println("You have entered a incorrect age!!!");
                             System.out.print("Please re-nter student's age>> ");
                             returnVal=0;
                         }

               }

 return returnVal;
}//end of method
       
}//end of class

    //Q1 DONE
//CODE WORKING 100%